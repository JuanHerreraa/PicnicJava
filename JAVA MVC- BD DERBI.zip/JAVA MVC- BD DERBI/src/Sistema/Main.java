
/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
 */
package Sistema;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import javax.swing.JFrame;

import Controlador.Controlador;

import Dao.Persistencia;

import vista.*;


/**
 *
 * @author xf
 */
public class Main {
    public static void main(String[] args) {

//      TODO code application logic here
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("IntegradorParcialPU");

        // creo objeto de Persistencia (DAO)
        Persistencia persistencia = new Persistencia(emf);

        // creo controlador y asocio (inyecto) al controlador el objeto de Persistencia (DAO)
        Controlador c = new Controlador(persistencia);

        // creo la ventana principal, asocio (inyecto) el controlador
        VentanaPrincipal ventanaPrincipal = new VentanaPrincipal(c);

        ventanaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventanaPrincipal.setResizable(false);
        ventanaPrincipal.setLocationRelativeTo(null);
        ventanaPrincipal.setVisible(true);

        /*
         * ventanaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         * ventanaPrincipal.setResizable(false);
         * ventanaPrincipal.setLocationRelativeTo(null);
         * ventanaPrincipal.setVisible(true);/*
         */
    }
}


//~ Formatted by Jindent --- http://www.jindent.com
