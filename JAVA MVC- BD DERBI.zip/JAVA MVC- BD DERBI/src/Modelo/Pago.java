
/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;

/**
 *
 * @author Juan Herrera
 */
@Entity
@Table(name = "pagos")
public class Pago implements Serializable {

    @Id
    @GeneratedValue
    private Long idPago;

    @Temporal(javax.persistence.TemporalType.DATE)
    private Date fecha;

    @Basic
    private Double importe;

    @Basic
    private String tipo;

    @Basic
    private Contrato contrato;

    public Pago() {

    }

    public Pago(Double importe, Contrato contrato, String tipo) {
        this.importe = importe;
        this.contrato = contrato;
        this.tipo = tipo;
    }

    public Long getIdPago() {
        return idPago;
    }

    public void setIdPago(Long idPago) {
        this.idPago = idPago;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setImporte(Double importe) {
        this.importe = importe;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Contrato getContrato() {
        return contrato;
    }

    public void setContrato(Contrato contrato) {
        this.contrato = contrato;
    }

    @Override
    public String toString() {
        return "idPago: " + this.idPago + " Importe: " + this.importe + " Contrato: "
                + this.contrato + " Tipo: " + this.tipo;
    }

    public void getContrato(Contrato contrato) {
        this.contrato = contrato;
    }

    public void getTipo(String tipo) {
        this.tipo = tipo;
    }

}
