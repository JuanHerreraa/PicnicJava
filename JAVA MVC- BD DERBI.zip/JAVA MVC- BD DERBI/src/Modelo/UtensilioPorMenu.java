
/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.HashSet;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author Juan Herrera
 */
@Entity
@Table(name = "utensiliopormenu")
public class UtensilioPorMenu implements Serializable {

    @Id
    @GeneratedValue
    private Long idUtensilioPorMenu;

    @Basic
    private Menu menu;

    @Basic
    private int cantidad;

    @ManyToOne
    private Utensilio utensilio;

    public UtensilioPorMenu() {
    }

    public UtensilioPorMenu(Menu menu, Utensilio utensilio, int cantidad) {
      this.menu=menu;
      this.utensilio=utensilio;
      this.cantidad=cantidad;
    }

    public Long getIdUtensilioPorMenu() {
        return idUtensilioPorMenu;
    }

    public void setIdUtensilioPorMenu(Long idUtensilioPorMenu) {
        this.idUtensilioPorMenu = idUtensilioPorMenu;
    }

    public Menu getMenu() {
        return menu;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    public Utensilio getUtensilio() {
        return utensilio;
    }

    public void setUtensilio(Utensilio utensilio) {
        this.utensilio = utensilio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return " IDUtensilioPorMenu: " + this.idUtensilioPorMenu + " Menu: " + this.menu
                + " Utensilio: " + this.utensilio + " -Cantidad: " + this.cantidad;
    }

    public void getCantidad(int cantidad) {

    }

    public void getMenu(Menu menu) {
        this.menu = menu;
    }

    public void getUtensilio(Utensilio utensilio) {
        this.utensilio = utensilio;

    }

}
