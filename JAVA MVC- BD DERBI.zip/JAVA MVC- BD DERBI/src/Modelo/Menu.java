
/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Juan Herrera
 */
@Entity
@Table(name = "menus")
public class Menu implements Serializable {

    @Id
    @GeneratedValue
    private Long idMenu;

    @Basic
    private String descripcion;

    @Basic
    private double precio;

    @Basic
    private String utensiliosutiliza;
    @Basic
    private String alimentosutiliza;

    @ManyToOne
    private Alimento alimentos;
    @ManyToOne
    private Utensilio utensilios;

    @OneToMany(mappedBy = "menu")
    private List<AlimentoPorMenu> alimentoPorMenus;

    public Menu() {
    }

    public Menu(String descripcion, double precio) {
        this.descripcion = descripcion;
        this.precio = precio;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public List<AlimentoPorMenu> getAlimentoPorMenus() {
        return alimentoPorMenus;
    }

    public void setAlimentoPorMenus(List<AlimentoPorMenu> alimentoPorMenus) {
        this.alimentoPorMenus = alimentoPorMenus;
    }

    public Long getIdMenu() {
        return idMenu;
    }

    public void setIdMenu(Long idMenu) {
        this.idMenu = idMenu;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Alimento getAlimentos() {
        return alimentos;
    }

    public void setAlimentos(Alimento alimentos) {
        this.alimentos = alimentos;
    }

    public Utensilio getUtensilios() {
        return utensilios;
    }

    public void setUtensilios(Utensilio utensilios) {
        this.utensilios = utensilios;
    }

    public String getUtensiliosutiliza() {
        return utensiliosutiliza;
    }

    public void setUtensiliosutiliza(String utensiliosutiliza) {
        this.utensiliosutiliza = utensiliosutiliza;
    }

    public String getAlimentosutiliza() {
        return alimentosutiliza;
    }

    public void setAlimentosutiliza(String alimentosutiliza) {
        this.alimentosutiliza = alimentosutiliza;
    }

    @Override
    public String toString() {
        return " idMenu: " + this.idMenu + " Nombre: " + this.descripcion + " Precio: " + this.precio;
    }

}
