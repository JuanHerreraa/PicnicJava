
/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author Juan Herrera
 */
@Entity
@Table(name = "alimentopormenu")
public class AlimentoPorMenu implements Serializable {

    @Id
    @GeneratedValue
    private Long idAlimentopormenu;

    @Basic
    private int cantidad;

    @ManyToOne
    private Alimento alimento;

    @ManyToOne
    private Menu menu;

    public AlimentoPorMenu() {
    }

    public AlimentoPorMenu(Menu menus, Alimento alimentos, int cantidad) {
        this.menu = menu;
        this.alimento = alimento;
        this.cantidad = cantidad;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public Long getIdAlimentopormenu() {
        return idAlimentopormenu;
    }

    public void setIdAlimentopormenu(Long idAlimentopormenu) {
        this.idAlimentopormenu = idAlimentopormenu;
    }

    public Alimento getAlimento() {
        return alimento;
    }

    public void setAlimento(Alimento alimento) {
        this.alimento = alimento;
    }

    public Menu getMenu() {
        return menu;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    @Override
    public String toString() {
        return "idAlimentoPorMenu" + this.idAlimentopormenu + " -Menu" + this.menu
                + " Alimento:  " + this.alimento
                + " Cantidad" + this.cantidad;
    }

}
