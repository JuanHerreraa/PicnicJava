
/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;

//* La lista de contrato debe ser inmutable, toda clase que devuelva  .......//*
/**
 *
 * @author Juan Herrera
 */
@Entity
@Table(name = "contrato")
public class Contrato implements Serializable {

    @Id
    @GeneratedValue
    private Long idContrato;

    @Basic
    private String lugar;

    @Basic
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date fecha;

    @Basic
    private int cantidad;

    private double total;

    @ManyToOne
    private Cliente cliente;
    @ManyToOne
    private Menu menu;

    @OneToMany
    private List<Pago> pago = new ArrayList<>();

    public Contrato() {
    }

    public Contrato(String lugar, Date fecha, Cliente cliente, Menu menu, int cantidad) {
        this.lugar = lugar;
        this.fecha = fecha;
        this.cliente = cliente;
        this.menu = menu;
        this.cantidad = cantidad;
        this.total = this.cantidad * this.menu.getPrecio();

    }

    public static Date parseDate(String date) {
        try {
            return new SimpleDateFormat("dd/MM/yyyy").parse(date);
        } catch (ParseException e) {
            return null;
        }
    }

    public double getTotal() {
        return total;
    }

    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public Long getIdContrato() {
        return idContrato;
    }

    public void setIdContrato(Long idContrato) {
        this.idContrato = idContrato;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Menu getMenu() {
        return menu;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    public List<Pago> getPago() {
        return pago;
    }

    public void setPago(List<Pago> pago) {
        this.pago = pago;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return " IDCONTRATO " + this.idContrato + " -Lugar:" + this.lugar + " -Fecha:" + this.fecha
                + " -Menu:" + this.menu.getDescripcion() + " -Precio" + this.menu.getPrecio()
                + "IDCliente:" + this.cliente.getIdCliente() + " - Cliente" + this.cliente.getNombre()
                + " -Apellido:" + this.cliente.getApellido() + "-"
                + " -Cantidad: " + this.cantidad + " -Total: " + this.total;
    }

    public void getTotal(double total) {
        this.total = total;
    }

    public void getLugar(String lugar) {
        this.lugar = lugar;
    }

    public void getFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void getMenu(Menu menu) {
        this.menu = menu;
    }

    public void getCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public void getCliente(Cliente cliente) {
        this.cliente = cliente;
    }

}
