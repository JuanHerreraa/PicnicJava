
/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Juan Herrera
 */
@Entity
@Table(name = "cliente")
public class Cliente implements Serializable {

    @Id
    @GeneratedValue
    private long idCliente;

    @Basic
    private String nombre;

    @Basic
    private String apellido;

    @Basic
    private String direccion;

    @Basic
    private String telefono;

    @OneToMany(mappedBy = "cliente")
    private List<Contrato> contrato;

    public Cliente() {
        contrato = new ArrayList<>();
    }

    public Cliente(String nombre, String apellido, String direccion, String telefono) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.telefono = telefono;
        //   contrato = (List<Contrato>) new HashSet(); //<< NOSE SI ESTA BIEN <//
    }

    public Long getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public List<Contrato> getContrato() {
        return contrato;
    }

    public void setContrato(List<Contrato> contrato) {
        this.contrato = contrato;
    }

    @Override
    public String toString() {
        return " IDCliente: " + this.idCliente + " -Nombre: " + this.nombre + " -Apellido: " + this.apellido
                 +" -Direccion: " + this.direccion + " -Telefono: " + this.telefono;
    }

    /*
  public Set<Contrato> getcontrato() {
       if (contrato == null) {
           contrato = new HashSet<>();  
        }
       return contrato; //
   } 
   
    
    
    
    
    public void setcontrato(Set<Contrato> contrato) {
        this.contrato = (List<Contrato>) contrato; // << esta casteado nose si esta bien<</
    }

    @Override
    public String toString() {
        return this.idCliente + " - " + this.nombre;
    }

    public void addContrato(Contrato contrato) {
        getcontrato().add(contrato);
        contrato.setCliente(this);
    }

    public void removeContrato(Contrato contrato) {
        getcontrato().remove(contrato);
        contrato.setCliente(null);
    }
     */
}
