
/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.metamodel.SingularAttribute;

/**
 *
 * @author Juan Herrera
 */
@Entity
@Table(name = "utensilio")
public class Utensilio implements Serializable {

    @Id
    @GeneratedValue
    private long idUtensilio;

    @Basic
    private String nombre;

    @Basic
    private String cantidad;

    @OneToMany(mappedBy = "utensilios")
    private List<Menu> menu;
    @OneToMany(mappedBy = "utensilio")
    private List<UtensilioPorMenu> utensiliosPorMenus;

    public Utensilio(){}
    
    public Utensilio(String nombre, String cantidad) {
        this.nombre = nombre;
        this.cantidad = cantidad;
      
    }

    public Utensilio(String nombre, SingularAttribute<Cliente, String> apellido) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Long getIdUtensilio() {
        return idUtensilio;
    }

    public void setIdUtensilio(long idUtensilio) {
        this.idUtensilio = idUtensilio;
    }

    public List<Menu> getMenu() {
        return menu;
    }

    public void setMenu(List<Menu> menu) {
        this.menu = menu;
    }

    public List<UtensilioPorMenu> getUtensiliosPorMenus() {
        return utensiliosPorMenus;
    }

    public void setUtensiliosPorMenus(List<UtensilioPorMenu> utensiliosPorMenus) {
        this.utensiliosPorMenus = utensiliosPorMenus;
    }

    public Utensilio(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
       
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }
    

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    @Override
    public String toString() {
        return  "idUtensilio" +this.idUtensilio + "nombre:"+ this.nombre + "cantidad: "+ this.cantidad + "";
    }

    public boolean isEmpty() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Object[] toArray() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void getNombre(String nombre) {
this.nombre=nombre;    }

    public void getCantidad(String cantidad) {
this.cantidad=cantidad;
    }
}


