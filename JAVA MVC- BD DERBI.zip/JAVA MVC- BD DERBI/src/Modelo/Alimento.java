
/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
 */
package Modelo;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Juan Herrera
 */
@Entity
@Table(name = "alimento")
public class Alimento implements Serializable {
    @Id
    @GeneratedValue
    private Long idAlimento;
    
    @Basic
    public String nombre;

    @Basic
    private int cantidad;

    @OneToMany(mappedBy = "alimentos") /*va con s */
    private List<Menu> menu;
    @OneToMany(mappedBy = "alimento")
    private List<AlimentoPorMenu> alimentoMenu;

    public Alimento() {
    }


    public Alimento(String nombre, int cantidad) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        /*
        menu = (List<Menu>) new HashSet();
        alimentoMenu = (List<AlimentoPorMenu>) new HashSet();
        */
    
        }

    public Long getIdAlimento() {
        return idAlimento;
    }

    public void setIdAlimento(Long idAlimento) {
        this.idAlimento = idAlimento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public List<Menu> getMenu() {
        return menu;
    }

    public void setMenu(List<Menu> menu) {
        this.menu = menu;
    }

    public List<AlimentoPorMenu> getAlimentoMenu() {
        return alimentoMenu;
    }

    public void setAlimentoMenu(List<AlimentoPorMenu> alimentoMenu) {
        this.alimentoMenu = alimentoMenu;
    }
     @Override
    public String toString() {
        return  "idAlimento" +this.idAlimento + "nombre:  "+ this.nombre + "cantidad:  "+ this.cantidad;
    }

    public void getNombre(String nombre) {
this.nombre=nombre;    }

    public void getCantidad(int unidad) {
this.cantidad=cantidad;    }

    public boolean isEmpty() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
/*
   public Set<Menu> getmenu() {
      if (menu == null) {
          menu = new HashSet<>();
      }
     return (Set<Menu>) menu;
   }

    public void setmenu(Set<Menu> envases) {
        this.menu = menu;
    }

    public void addmenu(Menu envase) {
        getmenu().add(envase);
        envase.setMenu(this);
    }

    public void removemenu(Menu envase) {
        getmenu().remove(envase);
        envase.setMenu(null);
    }
///////////////////////////////////////////////////
    public Set<AlimentoMenu> getAlimentoMenu() {
        if (alimentoMenu == null) {
            alimentoMenu = new HashSet<>();
        }
        return alimentoMenu;
    }

    public void setAlimentoMenu(Set<AlimentoMenu> alimentoMenu) {
        this.alimentoMenu = (List<AlimentoPorMenu>) alimentoMenu;
    }

    @Override
    public String toString() {
        return this.idAlimento + " - " + this.nombre;
    }

    public void addAlimentoMenu(Menu alimentoMenu) {
        getAlimentoMenu().add(alimentoMenu);
        alimentoMenu.setAlimentoMenu(this);
    }

    public void removeAlimentoMenu(Menu alimentoMenu) {
        getAlimentoMenu().remove(alimentoMenu);
        alimentoMenu.setAlimentoMenu(null);
    }

}
*/

