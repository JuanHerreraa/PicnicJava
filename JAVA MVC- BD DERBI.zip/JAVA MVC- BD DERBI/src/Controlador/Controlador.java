
/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
 */
package Controlador;

import java.util.List;

import Dao.Persistencia;
import Modelo.Alimento;
import Modelo.AlimentoPorMenu;
import Modelo.AlimentoPorMenu_;
import Modelo.Alimento_;
import Modelo.Cliente;
import Modelo.Cliente_;
import Modelo.Contrato;
import Modelo.Contrato_;
import Modelo.Menu;
import Modelo.Menu_;
import Modelo.Pago;
import Modelo.Pago_;
import Modelo.Utensilio;
import Modelo.Utensilio_;
import Modelo.UtensilioPorMenu;
import Modelo.UtensilioPorMenu_;
import java.util.Date;

public class Controlador {

    Persistencia persistencia;

    public Controlador(Persistencia p) {
        this.persistencia = p;
    }

    /*CLIENTES*/
    public List listarCliente() {
        // retorno valores ordenados de la consulta
        return this.persistencia.buscarTodosOrdenadosPor(Cliente.class, Cliente_.nombre);
    }

    public void agregarCliente(String nombre, String apellido, String direccion, String telefono) {
        this.persistencia.iniciarTransaccion();

        Cliente c = new Cliente(nombre.toUpperCase(), apellido.toUpperCase(), direccion.toUpperCase(), telefono.toUpperCase());
        this.persistencia.insertar(c);
        this.persistencia.confirmarTransaccion();
    }

    public Cliente buscarCliente(Long idCliente) {
        return this.persistencia.buscar(Cliente.class, idCliente);
    }

    public void editarCliente(Cliente c, String nombre, String apellido, String direccion, String telefono) {
        this.persistencia.iniciarTransaccion();
        c.setNombre(nombre);
        c.setApellido(apellido);
        c.setDireccion(direccion);
        c.setTelefono(telefono);
        this.persistencia.modificar(c);
        this.persistencia.confirmarTransaccion();
    }

    public int eliminarCliente(Cliente c) {
        if (c.getContrato().isEmpty()) {  //* NOSE SI ESTA BIEN ASOCIADO <//*
            this.persistencia.iniciarTransaccion();
            this.persistencia.eliminar(c);
            this.persistencia.confirmarTransaccion();
            return 0;
        } else {
            return 1;
        }
    }

    /// ALIMENTOS //*
    public List listarAlimento() {
        // retorno valores ordenados de la consulta
        return this.persistencia.buscarTodosOrdenadosPor(Alimento.class, Alimento_.nombre);
    }

    public Alimento buscarAlimento(Long idArticulo) {
        return this.persistencia.buscar(Alimento.class, idArticulo);
    }

    public void agregarAlimento(String nombre, int unidad) {
        this.persistencia.iniciarTransaccion();
        Alimento a = new Alimento(nombre, unidad);
        this.persistencia.insertar(a);
        this.persistencia.confirmarTransaccion();

    }

    public void editarAlimento(Alimento a, String nombre, int cantidad) {
        this.persistencia.iniciarTransaccion();
        a.setNombre(nombre);
        a.setCantidad(cantidad);
        this.persistencia.modificar(a);
        this.persistencia.confirmarTransaccion();
    }

    public int eliminarAlimento(Alimento alimentos) {
        if (alimentos.getNombre().isEmpty()) {  // QUE DEVUELVE ?//
            this.persistencia.iniciarTransaccion();
            this.persistencia.eliminar(alimentos);
            this.persistencia.confirmarTransaccion();
            return 0;
        } else {
            return 1;
        }
    }

    // UTENSILIOS //*
    public List listarUtensilio() {
        // retorno valores ordenados de la consulta
        return this.persistencia.buscarTodosOrdenadosPor(Utensilio.class, Utensilio_.nombre);
    }

    public Utensilio buscarUtensilio(Long idUtensilio) {
        return this.persistencia.buscar(Utensilio.class, idUtensilio);
    }

    public void agregarUtensilio(String nombre, String cantidad) {
        this.persistencia.iniciarTransaccion();
        Utensilio c = new Utensilio(nombre, cantidad);
        this.persistencia.insertar(c);
        this.persistencia.confirmarTransaccion();

    }

    public void editarUtensilio(Utensilio p, String nombre, String cantidad) {
        this.persistencia.iniciarTransaccion();
        p.setNombre(nombre);
        p.setCantidad(cantidad);
        this.persistencia.modificar(p);
        this.persistencia.confirmarTransaccion();

    }

    public int eliminarUtensilio(Utensilio p) {
        if (p.getMenu().isEmpty()) {  // QUE DEVUELVE ?//
            this.persistencia.iniciarTransaccion();
            this.persistencia.eliminar(p);
            this.persistencia.confirmarTransaccion();
            return 0;
        } else {
            return 1;
        }

    }

    /*MENUS*/
    public List listarMenu() {
        //RETORNAR VALORES
        return this.persistencia.buscarTodosOrdenadosPor(Menu.class, Menu_.descripcion); //DEVUELVE LA DESCRIPCION?//*
    }

    public Menu buscarMenu(Long idMenu) {
        return this.persistencia.buscar(Menu.class, Menu_.idMenu);

    }

    public int eliminarMenu(Menu en) {
        if (en.getAlimentoPorMenus().isEmpty()) { // A DONDE HACER REFERECNCIA? //*
            this.persistencia.iniciarTransaccion();
            this.persistencia.eliminar(en);
            this.persistencia.confirmarTransaccion();
            return 0;
        } else {
            return 1;
        }

    }

    public void editarMenu(Menu en, String descripcion, double precio) {
        this.persistencia.iniciarTransaccion();
        en.setDescripcion(descripcion);
        en.setPrecio(precio);
        this.persistencia.modificar(en);
        this.persistencia.confirmarTransaccion();
    }

    public void agregarMenu(String descripcion, double precio) {
        this.persistencia.iniciarTransaccion();
        Menu en = new Menu(descripcion.toUpperCase(), precio);
        this.persistencia.insertar(en);
        this.persistencia.confirmarTransaccion();
    }

    /*PAGOS*/
    public List listarPago() {
        // retorno valores ordenados de la consulta
        return this.persistencia.buscarTodosOrdenadosPor(Pago.class, Pago_.idPago);
    }

    public Pago buscarPago(Long idPago) {
        return this.persistencia.buscar(Pago.class, idPago);
    }

    public void agregarPago(double importe, Contrato contrato, String tipo) {
        this.persistencia.iniciarTransaccion();
        Pago c = new Pago(importe, contrato, tipo.toUpperCase());
        this.persistencia.insertar(c);
        this.persistencia.confirmarTransaccion();
    }

    public void editarPago(Pago pago, Double importe, Contrato contrato, String tipo) {
        this.persistencia.iniciarTransaccion();
        pago.setImporte(importe);
        pago.setContrato(contrato);
        pago.setTipo(tipo);
        this.persistencia.modificar(pago);
        this.persistencia.confirmarTransaccion();
    }

    public int eliminarPago(Pago pagos) {
        if (pagos.getTipo().isEmpty()) {  // QUE DEVUELVE ?//
            this.persistencia.iniciarTransaccion();
            this.persistencia.eliminar(pagos);
            this.persistencia.confirmarTransaccion();
            return 0;
        } else {
            return 1;
        }
    }

    //* CONTRATO //*
    public List listarContrato() {
        // retorno valores ordenados de la consulta
        return this.persistencia.buscarTodosOrdenadosPor(Contrato.class, Contrato_.idContrato);
    }

    public Contrato buscarContrato(Long idContrato) {
        return this.persistencia.buscar(Contrato.class, idContrato);
    }

    public void agregarContrato(String lugar, Date fecha, Cliente cliente, Menu menu, int cantidad) {
        this.persistencia.iniciarTransaccion();
        Contrato en = new Contrato(lugar.toUpperCase(), fecha, cliente, menu, cantidad);
        this.persistencia.insertar(en);
        this.persistencia.confirmarTransaccion();
    }

    public void editarContrato(Contrato contratos, String lugar, Date fecha, Cliente cliente, Menu menu, int cantidad) {
        this.persistencia.iniciarTransaccion();
        contratos.setLugar(lugar);
        contratos.setFecha(fecha);
        contratos.setCliente(cliente);
        contratos.setMenu(menu);
        contratos.setCantidad(cantidad);
        this.persistencia.modificar(contratos);
        this.persistencia.confirmarTransaccion();
    }

    public int eliminarContrato(Contrato en) {
        if (en.getPago().isEmpty()) {  // QUE DEVUELVE ?//
            this.persistencia.iniciarTransaccion();
            this.persistencia.eliminar(en);
            this.persistencia.confirmarTransaccion();
            return 0;
        } else {
            return 1;
        }

    }

    //ALIMENTO POR MENU //
    public List listarAlimentoPorMenu() {
        // retorno valores ordenados de la consulta
        return this.persistencia.buscarTodosOrdenadosPor(AlimentoPorMenu.class, AlimentoPorMenu_.idAlimentopormenu);
    }

    public Alimento buscarAlimento(String idAlimentopormenu, String fecha, int cantidad) {
        return this.persistencia.buscar(Alimento.class, idAlimentopormenu);
    }

    public void agregarAlimentoPorMenu(Menu menu, Alimento alimento, int cantidad) {
        this.persistencia.iniciarTransaccion();
        AlimentoPorMenu c = new AlimentoPorMenu(menu, alimento, cantidad);
        c.setMenu(menu);
        c.setAlimento(alimento);
        this.persistencia.insertar(c);
        this.persistencia.confirmarTransaccion();
    }

    public void editarAlimentoPorMenu(AlimentoPorMenu alimentopormenus, Menu menu, Alimento alimento, int cantidad) {
        this.persistencia.iniciarTransaccion();
        alimentopormenus.setMenu(menu);
        alimentopormenus.setAlimento(alimento);
        alimentopormenus.setCantidad(cantidad);
        this.persistencia.modificar(alimentopormenus);
        this.persistencia.confirmarTransaccion();
    }

    public int eliminarAlimentoPorMenu(AlimentoPorMenu alimentopormenus) {
        if (alimentopormenus.getAlimento().isEmpty()) {  // QUE DEVUELVE ?//
            this.persistencia.iniciarTransaccion();
            this.persistencia.eliminar(alimentopormenus);
            this.persistencia.confirmarTransaccion();
            return 0;
        } else {
            return 1;
        }
    }

    //UTENSILIO POR MENU//
    public List listarUtensiliopormenu() {
        // retorno valores ordenados de la consulta
        return this.persistencia.buscarTodosOrdenadosPor(UtensilioPorMenu.class, UtensilioPorMenu_.menu);
    }

    public UtensilioPorMenu buscarUtensiliopormenu(int idutensiliopormenu, String nombre, int cantidad) {
        return this.persistencia.buscar(UtensilioPorMenu.class, idutensiliopormenu);
    }

    public void agregarUtensilioPorMenu(Menu menu, Utensilio utensilio, int cantidad) {
        this.persistencia.iniciarTransaccion();
        UtensilioPorMenu c = new UtensilioPorMenu(menu, utensilio, cantidad);
        this.persistencia.insertar(c);
        this.persistencia.confirmarTransaccion();

    }

    public void editarUtensilioPorMenu(UtensilioPorMenu p, Menu menu, Utensilio utensilio, int cantidad) {
        this.persistencia.iniciarTransaccion();
        p.setMenu(menu);
        p.setUtensilio(utensilio);
        p.setCantidad(cantidad);
        this.persistencia.modificar(p);
        this.persistencia.confirmarTransaccion();
    }

    public int eliminarUtensilioPorMenu(UtensilioPorMenu utensiliospormenu) {
        if (utensiliospormenu.getUtensilio().isEmpty()) {  // QUE DEVUELVE ?//
            this.persistencia.iniciarTransaccion();
            this.persistencia.eliminar(utensiliospormenu);
            this.persistencia.confirmarTransaccion();
            return 0;
        } else {
            return 1;
        }
    }

}
